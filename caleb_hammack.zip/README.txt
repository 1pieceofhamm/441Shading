Caleb Hammack README

Everything should work as intended. No extra credit parts.